package com.test.demo.component;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

/**
 * 面向切面
 * 记录接口访问日志
 */
@Aspect
@Component
public class WebLogAspect {
    @Autowired LogDataService logDataService;

    ThreadLocal<Long> startTime = new ThreadLocal<>();
    ThreadLocal<InterFaceLog> log = new ThreadLocal<>();
    InterFaceLog interfaceLog =  new InterFaceLog();

    @Pointcut("execution(public * com.test.demo.controller.api.*(..))")
    public void webLog(){}

    @Before("webLog()")
    public void doBefore(JoinPoint joinPoint) throws Throwable {
        // 接收到请求，记录请求内容
        startTime.set(System.currentTimeMillis());
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String url = request.getRequestURL().toString();
        String method = request.getMethod();
        String remoteAddr = request.getRemoteAddr();
        String class_method = joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName();
        String param = Arrays.toString(joinPoint.getArgs());

        SysUser loginUser = CommonUtil.getLoginUser();
        if (!CommonUtil.check(loginUser)){
            return;
        }
        interfaceLog.setCallerAcc(loginUser.getAccNum());
        interfaceLog.setCallerID(loginUser.getUserID());
        interfaceLog.setClass_method(class_method);
        interfaceLog.setMethod(method);
        interfaceLog.setUrl(url);
        interfaceLog.setRemoteAddr(remoteAddr);
        interfaceLog.setParam(param);
        log.set(interfaceLog);
    }

    @AfterReturning(returning = "ret", pointcut = "webLog()")
    public void doAfterReturning(Object ret) throws Throwable {
        String result = ret.toString();
        InterFaceLog logAfter =  log.get();
        Long time = System.currentTimeMillis() - startTime.get();
        logAfter.setResult(result);
        logAfter.setCallTm(DateUtil.dateToYMDHMS(new Date()));
        logAfter.setTime(time);
        logAfter.setId(UUID.randomUUID().toString());
        ApiResult apiResult = logService.addLog(logAfter);
        System.out.println("apiResult ------------ "+apiResult);
        System.out.println(logAfter);
    }
}
