package com.test.demo.controller.api;
import com.test.demo.component.WebLogAspect;
import com.test.demo.pojo.LogData;
import com.test.demo.pojo.User;
import com.test.demo.utils.InfoUtils;
import com.test.demo.utils.TokenUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * 访问接口的api
 */

@RestController
@RequestMapping("/api")
public class GetInfoController {
    @Autowired UserService userService;
    @Autowired LogDataService logDataService;
    @Autowired WebLogAspect webLogAspect;
    TokenUtils tokenUtils=new TokenUtils();
    InfoUtils infoUtils=new InfoUtils();

    @RequestMapping("/history/{timeParam}")
    public String getInfo(@RequestBody User user,@PathVariable("timeParam") String timeParam){
        JSONObject jsonObject=new JSONObject();
        User user=userService.findByUsername(user);
        if(user==null){
            JsonObj.put("message","用户无权访问");
            return JsonObj;
        }else {
            if (!user.getPassword().equals(user.getPassword())){
                jsonObject.put("message","用户无权访问");
                return JsonObj;
            }else {
                //验证成功返回token
                String token = tokenUtils.getToken(user);
                jsonObject.put("token", token);
                jsonObject.put("user", user);
                //日志解析入库
                LogData logData =infoUtils.getInfo(url);
                logDataService.save(logData);
            }
        }
    }
}
