package com.test.demo.repository;

import com.test.demo.pojo.LogData;
import org.springframework.data.repository.CrudRepository;

public interface LogDataRepository extends CrudRepository<LogData,Long> {

}
