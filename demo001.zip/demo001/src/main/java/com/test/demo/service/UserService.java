package com.test.demo.service;

import com.test.demo.pojo.User;
import com.test.demo.repository.UserRepository;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import javax.transaction.Transactional;

@Service
public class UserService {
    @Resource
    private UserRepository userRepository;
    @Transactional
    public User findByUserName(String userName){
        return userRepository.findByUserName(userName);
    }
    public User findUserById(String id){
        return userRepository.findUserById(id);
    }
}
