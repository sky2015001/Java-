package com.test.demo.repository;

import com.test.demo.pojo.User;
import org.springframework.data.repository.CrudRepository;
/*
 * CrudRepository自带常用的crud方法
 */
public interface UserRepository extends CrudRepository<User,Long>{}
