package com.test.demo.service;

import com.test.demo.pojo.LogData;
import com.test.demo.repository.LogDataRepository;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import javax.transaction.Transactional;

    @Service
    public class LogDataService {
        @Resource
        private LogDataRepository LogDataRepository;
        @Transactional
        public void save(LogData demo){
            logDataRepository.save(demo);
        }
    }


