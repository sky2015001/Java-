package com.test.demo.utils;

import sun.net.www.http.HttpClient;

/**
 * 发送请求到查询历史今天的免费接口
 */
public class InfoUtils {

    public String getInfo(String url){
        HttpClient client = HttpClients.createDefault();
        HttpPost post = new HttpPost(url);
        try {
            StringEntity s = new StringEntity(date.toString());
            s.setContentEncoding("UTF-8");
            s.setContentType("application/json");
            post.setEntity(s);
            post.addHeader("content-type", "text/xml");
            HttpResponse res = client.execute(post);
            String response = EntityUtils.toString(res.getEntity());
            if (res.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                String result = EntityUtils.toString(res.getEntity());
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return result;
    }
}
