package com.test.demo.utils;
import com.test.demo.pojo.User;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

/**
 * 生成token工具类
 */
public class TokenUtils {
    public String getToken(User user) {
        String token= JWT.create().withAudience(user.getId())
                .sign(Algorithm.HMAC256(user.getPassword()));
        return token;
    }
}
