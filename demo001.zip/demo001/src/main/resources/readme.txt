1、项目采用 Springboot+jpa+mysql 架构
2、用token验证，使用过滤器过滤不需要验证的请求
3、接口访问日志这部分是面向切面的配置
